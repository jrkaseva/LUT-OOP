package main;
public interface PrintInfo {
    public String getInformation();
}
