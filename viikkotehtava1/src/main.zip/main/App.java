package main;
/*
 * Author: Joakim Kaseva
 * Viikkotehtävä 1 - LUT Olio-ohjelmointi kurssi
 */
public class App {
    /*
     * tulostaa Hello World! konsoliin.
     */
    public static void main(String[] args){
        System.out.println("Hello World!");
    }
}